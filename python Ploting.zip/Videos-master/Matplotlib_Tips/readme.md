Code associated with my "Matplotlib Tips" video series.  Check out my [full playlist on YouTube](https://www.youtube.com/playlist?list=PLtPIclEQf-3dJmAj3IsSRwRoLbX-n3J81).
